# Summary of changes for run 6fa7e757-9065-41e7-80a0-dcf746bd6e69
Created `claim_H4_permutation_invariance.lean` with a complete, sorry-free proof of Claim H4: Total Rendering Weight is Permutation-Invariant.

**What was proved:**

1. **`T_eq_prod`** — The transmittance `T a n` equals the finite product `∏ i ∈ range n, (1 - a i)`, proved by induction.

2. **`prod_one_sub_perm`** — The product `∏ (1 - a(σ(i)))` equals `∏ (1 - a(i))` for any permutation σ, using commutativity of multiplication (`Equiv.Perm.prod_comp`).

3. **`total_weight_perm_invariant`** (Main Theorem H4) — For any permutation σ of `Fin n`, the total rendering weight `∑ w(a', i)` with permuted opacities equals `∑ w(a, i)`. The proof chains the telescoping identity (`∑ w = 1 - T`) with the product representation of T and permutation invariance of products.

4. **`two_element_total_weight`** — The total weight for two elements equals `a₁ + a₂ - a₁ * a₂`.

5. **`two_element_total_weight_comm`** — The two-element total weight is symmetric (swapping elements doesn't change the total).

The file follows the same style and definitions (`T`, `w`, `w_eq_T_sub`, `alpha_compositing_sum`) as `claim_3_1_weights_sum_bounded.lean`. All proofs compile cleanly with no sorries and only standard axioms (`propext`, `Classical.choice`, `Quot.sound`).